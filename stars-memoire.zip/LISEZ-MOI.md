# STARS AI — Mémoire intelligente : installation

## Ce qui est déjà fait
- **Base de données (Supabase)** : tables `stars_memories` et `stars_memory_settings` + 7 fonctions `stars_memory_*`. **Déjà appliqué** sur ton projet « stars ai ». Rien d'existant n'a été modifié (ni comptes, ni Premium, ni paiements, ni admin, ni les tables `conversations` / `messages`).
- 25 vérifications SQL réussies (isolation entre utilisateurs, limite de 100, doublons, désactivation, purge) et droits contrôlés : `anon` et `authenticated` n'ont aucun accès direct aux tables.

## Fichiers à mettre sur GitHub
| Fichier | Où | Action |
|---|---|---|
| `server.js` | racine du dépôt | **remplace** l'ancien (il contient aussi le secours Gemini et répare le fichier cassé) |
| `memory.js` | racine du dépôt | nouveau |
| `public/memoire.html` | dossier `public` | nouveau (page « Mes souvenirs », adresse : `/memoire`) |
| `public/images.html` | dossier `public` | nouveau (page « Images », adresse : `/images`) |
| `tests/` | dossier `tests` | facultatif (tests automatiques) |
| `migration_memoire.sql`, `migration_images.sql` | — | **inutiles** : déjà appliqués sur Supabase (conservés pour mémoire) |

Depuis un ordinateur : dézippe `stars-memoire.zip`, ouvre `https://github.com/yvanemambo/stars-ai.zip/upload/main`, glisse `server.js`, `memory.js` et le dossier `public`, puis « Valider les modifications ».

**Vérifier que rien d'autre n'a changé** : une fois déposé, ouvre
`https://github.com/yvanemambo/stars-ai.zip/compare/173f312...main`
Cette page montre toutes les différences avec la version qui marchait le 30 octobre : tu ne dois voir que le secours Gemini et la mémoire.

## Après le déploiement
Dans les journaux de Render, cherche : `[vérif] Mémoire (Supabase) OK.`
Si tu vois « Mémoire indisponible », la migration SQL n'est pas appliquée sur la bonne base.

## Réglages (aucun obligatoire)
- `MEMORY_ENABLED=0` : coupe toute la mémoire du site (retour au comportement d'avant).
- La mémoire est activée par défaut pour chaque personne ; chacune peut la désactiver sur `/memoire`.

## Fonctionnement
- **Isolation** : le serveur utilise toujours l'e-mail de la session, jamais un e-mail envoyé par le navigateur. Les fonctions SQL exigent en plus le secret de la base (`MEMBERS_SECRET`).
- **« Retiens que… » / « Oublie que… »** dans le chat. « Oublie tout » ne supprime rien : il renvoie vers `/memoire`.
- **Mémorisation automatique** : une requête supplémentaire à l'IA, seulement quand le message parle de l'utilisateur (« je prépare… », « mon projet… »). Maximum 3 par minute et 20 par heure et par personne.
- **Jamais enregistrés** (même sur demande) : mots de passe, clés API, cartes bancaires, IBAN, numéros de sécurité sociale ou de pièces d'identité. Santé, religion, politique, vie intime : jamais **automatiquement**.
- Les contenus des souvenirs **ne sont jamais écrits dans les journaux**.
- **Suppression du compte** : efface aussi les souvenirs et le réglage.

## Génération d'images (OpenAI) — ajout
**Fichiers** : le nouveau `server.js` (remplace l'ancien) + `public/images.html` (nouveau). `memory.js` et `memoire.html` ne changent pas.
**Base de données** : table `stars_image_usage` + 4 fonctions `stars_image_*`, **déjà appliquées** (14 vérifications SQL réussies).

**Réglage Render obligatoire** : une variable nommée exactement `OPENAI_API_KEY`. Sans elle, la fonction est désactivée.
Dans les journaux après déploiement : `[vérif] Clé OpenAI OK — images actives (modèle gpt-image-1, qualité low, …)`.

**Réglages facultatifs** (Render > Environment) :
| Variable | Défaut | Rôle |
|---|---|---|
| `IMAGE_FREE_DAILY` | 3 | images par jour et par compte gratuit |
| `IMAGE_PREMIUM_DAILY` | 30 | images par jour pour le Premium et le propriétaire |
| `IMAGE_SITE_DAILY` | 100 | plafond de tout le site par jour (protège ton budget) |
| `IMAGE_QUALITY` | low | `low`, `medium` ou `high` |
| `OPENAI_IMAGE_MODEL` | gpt-image-1 | modèle d'image |
| `IMAGES_ENABLED` | (actif) | `0` coupe la génération sans retirer la clé |

**Coût** (tarifs officiels OpenAI de gpt-image-1, image 1024×1024) : qualité basse ≈ 0,011 $, moyenne ≈ 0,042 $, haute ≈ 0,167 $. Avec les réglages par défaut, le maximum est de 100 images par jour pour tout le site, soit environ 1,10 $ par jour en qualité basse. **Fixe aussi une limite de dépense mensuelle** sur platform.openai.com (Billing > Limits).

**Garde-fous** :
- Une image n'est générée que si le compteur Supabase a réservé une place : compteur en panne = aucune génération.
- Une image qui échoue (refus, manque de crédit, erreur) est automatiquement rendue au quota.
- Une seule génération à la fois par personne ; 4 demandes par minute au maximum.
- La clé OpenAI reste sur le serveur ; ni la clé ni les demandes d'images ne sont écrites dans les journaux ; les images ne sont pas conservées sur le serveur.
- OpenAI filtre les demandes interdites, et le serveur ajoute une consigne « tous publics ».
- La suppression du compte efface les compteurs d'images.

**Si OpenAI refuse** : `org_not_verified` = il faut vérifier ton organisation sur platform.openai.com (obligatoire pour certains modèles d'images) ; `no_credit` = pas de crédit sur ton compte OpenAI ; `bad_key` = clé invalide.
**Limite** : pas de bouton « Images » dans le chat (`index.html` non modifié). La page est à l'adresse `/images`, et l'IA de chat y renvoie quand on lui demande une image.

## Tests
```
node --test tests/*.test.js
```
52 tests : filtre de sécurité, commandes retiens / oublie, isolation entre deux utilisateurs, cookie falsifié, désactivation, suppression de compte, journaux, images (quotas, coûts, remboursement, clé jamais exposée). Aucun réseau, aucune vraie clé.

## Limites connues
- La compréhension des **anciennes conversations** passe par les souvenirs retenus, pas par le texte complet des conversations (qui n'est pas stocké sur le serveur).
- Le filtre est volontairement prudent : une phrase qui contient « mot de passe » n'est jamais retenue, même si elle parle de sécurité en général.
- Pas de lien vers `/memoire` dans le chat : `public/index.html` n'a pas été modifié (je ne l'ai pas vu). Envoie-le pour ajouter un bouton « Mes souvenirs ».
- Penser à ajouter une phrase dans la page `/confidentialite` : « STARS AI peut mémoriser des informations que tu partages pour mieux te répondre. Tu peux les consulter, les modifier ou les supprimer sur /memoire, et les désactiver à tout moment. »

## Retour en arrière
1. Immédiat : `MEMORY_ENABLED=0` dans Render > Environment.
2. Complet (supprime aussi les souvenirs) :
```sql
drop function if exists public.stars_memory_get(text,text), public.stars_memory_add(text,text,text,text,text),
  public.stars_memory_update(text,text,bigint,text,text), public.stars_memory_delete(text,text,bigint),
  public.stars_memory_clear(text,text), public.stars_memory_set_enabled(text,text,boolean), public.stars_memory_purge(text,text);
drop schema if exists stars_private cascade;
drop table if exists public.stars_memories, public.stars_memory_settings;
```
Retour en arrière des images : `IMAGES_ENABLED=0`, ou pour tout supprimer :
```sql
drop function if exists public.stars_image_allow(text,text,integer,integer), public.stars_image_refund(text,text),
  public.stars_image_used(text,text), public.stars_image_purge(text,text);
drop table if exists public.stars_image_usage;
```
(à lancer avant `drop schema stars_private`, car ces fonctions en dépendent).
