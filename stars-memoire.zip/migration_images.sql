-- STARS AI : génération d'images — compteurs par personne et par jour (nouvelle table et nouvelles fonctions uniquement)
create table if not exists public.stars_image_usage (
  email text not null check (char_length(email) between 3 and 254),
  day   date not null,
  n     integer not null default 0 check (n >= 0),
  primary key (email, day)
);
alter table public.stars_image_usage enable row level security;
revoke all on public.stars_image_usage from public, anon, authenticated;

-- Réserve une image : refuse si la personne OU le site a atteint sa limite du jour (jour UTC).
create or replace function stars_private.img_allow(p_email text, p_limit integer, p_site_limit integer) returns jsonb
language plpgsql security definer set search_path = '' as $fn$
declare
  v_email text := lower(trim(coalesce(p_email, '')));
  v_day date := (now() at time zone 'utc')::date;
  v_site integer;
  v_n integer;
begin
  if char_length(v_email) < 3 then raise exception 'bad_email' using errcode = '22023'; end if;
  perform pg_advisory_xact_lock(hashtextextended('stars_images', 0));
  delete from public.stars_image_usage u where u.day < v_day - 40;
  select coalesce(sum(u.n), 0)::integer into v_site from public.stars_image_usage u where u.day = v_day;
  if v_site >= greatest(coalesce(p_site_limit, 0), 0) then return jsonb_build_object('ok', false, 'reason', 'site_limit'); end if;
  select u.n into v_n from public.stars_image_usage u where u.email = v_email and u.day = v_day;
  v_n := coalesce(v_n, 0);
  if v_n >= greatest(coalesce(p_limit, 0), 0) then
    return jsonb_build_object('ok', false, 'reason', 'user_limit', 'used', v_n, 'limit', p_limit);
  end if;
  insert into public.stars_image_usage as u (email, day, n) values (v_email, v_day, 1)
  on conflict (email, day) do update set n = u.n + 1;
  return jsonb_build_object('ok', true, 'used', v_n + 1, 'limit', p_limit);
end $fn$;

-- Rend une image réservée quand la génération a échoué (la personne ne perd pas son quota).
create or replace function stars_private.img_refund(p_email text) returns boolean
language plpgsql security definer set search_path = '' as $fn$
declare v_email text := lower(trim(coalesce(p_email, ''))); v_day date := (now() at time zone 'utc')::date;
begin
  if char_length(v_email) < 3 then raise exception 'bad_email' using errcode = '22023'; end if;
  update public.stars_image_usage u set n = greatest(u.n - 1, 0) where u.email = v_email and u.day = v_day;
  return found;
end $fn$;

create or replace function stars_private.img_used(p_email text) returns integer
language plpgsql security definer set search_path = '' as $fn$
declare v_email text := lower(trim(coalesce(p_email, ''))); v_n integer;
begin
  if char_length(v_email) < 3 then raise exception 'bad_email' using errcode = '22023'; end if;
  select u.n into v_n from public.stars_image_usage u where u.email = v_email and u.day = (now() at time zone 'utc')::date;
  return coalesce(v_n, 0);
end $fn$;

create or replace function stars_private.img_purge(p_email text) returns integer
language plpgsql security definer set search_path = '' as $fn$
declare v_email text := lower(trim(coalesce(p_email, ''))); v_n integer;
begin
  if char_length(v_email) < 3 then raise exception 'bad_email' using errcode = '22023'; end if;
  delete from public.stars_image_usage u where u.email = v_email;
  get diagnostics v_n = row_count;
  return v_n;
end $fn$;

-- Fonctions appelées par le serveur : elles exigent le secret, comme toutes les fonctions stars_*
create or replace function public.stars_image_allow(p_secret text, p_email text, p_limit integer, p_site_limit integer) returns jsonb
language plpgsql security definer set search_path = '' as $fn$
begin perform public.stars_check_secret(p_secret); return stars_private.img_allow(p_email, p_limit, p_site_limit); end $fn$;

create or replace function public.stars_image_refund(p_secret text, p_email text) returns boolean
language plpgsql security definer set search_path = '' as $fn$
begin perform public.stars_check_secret(p_secret); return stars_private.img_refund(p_email); end $fn$;

create or replace function public.stars_image_used(p_secret text, p_email text) returns integer
language plpgsql security definer set search_path = '' as $fn$
begin perform public.stars_check_secret(p_secret); return stars_private.img_used(p_email); end $fn$;

create or replace function public.stars_image_purge(p_secret text, p_email text) returns integer
language plpgsql security definer set search_path = '' as $fn$
begin perform public.stars_check_secret(p_secret); return stars_private.img_purge(p_email); end $fn$;

revoke all on function stars_private.img_allow(text, integer, integer) from public, anon, authenticated;
revoke all on function stars_private.img_refund(text) from public, anon, authenticated;
revoke all on function stars_private.img_used(text) from public, anon, authenticated;
revoke all on function stars_private.img_purge(text) from public, anon, authenticated;

revoke all on function public.stars_image_allow(text, text, integer, integer) from public, authenticated;
revoke all on function public.stars_image_refund(text, text) from public, authenticated;
revoke all on function public.stars_image_used(text, text) from public, authenticated;
revoke all on function public.stars_image_purge(text, text) from public, authenticated;
grant execute on function public.stars_image_allow(text, text, integer, integer) to anon, service_role;
grant execute on function public.stars_image_refund(text, text) to anon, service_role;
grant execute on function public.stars_image_used(text, text) to anon, service_role;
grant execute on function public.stars_image_purge(text, text) to anon, service_role;
